﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using Newtonsoft.Json;
using test.Classes;

namespace test
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //https://localhost:7100/api/Sale?dateStart=01.01.2021&dateEnd=01.02.2021
        }
        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://localhost:7100/api/Sale?dateStart=01.01.2021&dateEnd=01.01.2021");
            request.Method = "POST";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream stream = response.GetResponseStream();
            StreamReader sr = new StreamReader(stream);          
            var sReadData = sr.ReadToEnd();
            response.Close();
            List<Sale> d = new List<Sale>();
            d = JsonConvert.DeserializeObject<List<Sale>>(sReadData);
            lstTest.ItemsSource = d;
       }
    }
}
